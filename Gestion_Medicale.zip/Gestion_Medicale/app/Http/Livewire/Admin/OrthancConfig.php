<?php

namespace App\Http\Livewire\Admin;

use Livewire\Component;

class OrthancConfig extends Component
{
    public $orthancUrl;
    public $orthancUsername;
    public $orthancPassword;

    public function mount()
    {
        // Load existing config from .env or config files
        $this->orthancUrl = config('services.orthanc.url');
        $this->orthancUsername = config('services.orthanc.username');
        $this->orthancPassword = config('services.orthanc.password');
    }

    public function save()
    {
        // Save the config - in real app, this might update .env or a config file
        // Here, just simulate success message
        session()->flash('success', 'Configuration Orthanc sauvegardée avec succès.');
    }

    public function render()
    {
        return view('livewire.admin.orthanc-config');
    }
}
