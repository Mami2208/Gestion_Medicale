<?php

namespace App\Http\Livewire\Infirmier;

use Livewire\Component;
use Illuminate\Support\Facades\Auth;
use App\Models\Traitement;

class Soins extends Component
{
    public $tasks;

    public function mount()
    {
        $infirmier = Auth::user()->infirmier;
        if ($infirmier) {
            // Load care tasks (treatments) for patients assigned to the infirmier
            $this->tasks = Traitement::whereHas('patient', function ($query) use ($infirmier) {
                $query->where('infirmier_id', $infirmier->id);
            })->get();
        } else {
            $this->tasks = collect();
        }
    }

    public function render()
    {
        return view('livewire.infirmier.soins');
    }
}
