<?php

namespace App\Http\Livewire\Infirmier;

use Livewire\Component;
use Illuminate\Support\Facades\Auth;
use App\Models\Patient;

class Patients extends Component
{
    public $patients;

    public function mount()
    {
        $infirmier = Auth::user()->infirmier;
        if ($infirmier) {
            // Load patients assigned to the infirmier with priority/urgency indicator
            $this->patients = $infirmier->patients()->with('dossiersMedicaux')->get();
        } else {
            $this->patients = collect();
        }
    }

    public function render()
    {
        return view('livewire.infirmier.patients');
    }
}
