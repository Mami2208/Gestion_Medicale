<?php

namespace App\Http\Livewire\Secretaire;

use Livewire\Component;
use App\Models\Patient;
use App\Models\Dossiers_Medicaux;

class CreateDossier extends Component
{
    public $patient_id;
    public $description;

    protected $rules = [
        'patient_id' => 'required|exists:patients,id',
        'description' => 'required|string',
    ];

    public function submit()
    {
        $this->validate();

        Dossiers_Medicaux::create([
            'patient_id' => $this->patient_id,
            'description' => $this->description,
        ]);

        session()->flash('success', 'Dossier médical créé avec succès.');

        $this->reset(['patient_id', 'description']);
    }

    public function render()
    {
        $patients = Patient::with('utilisateur')->get();
        return view('livewire.secretaire.create-dossier', compact('patients'));
    }
}
