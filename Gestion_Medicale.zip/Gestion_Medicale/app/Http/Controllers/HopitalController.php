<?php

namespace App\Http\Controllers;

use App\Models\Hopital;
use Illuminate\Http\Request;

class HopitalController extends Controller
{
    public function index()
    {
        $hopitaux = Hopital::all();
        return view('admin.hopitaux.index', compact('hopitaux'));
    }

    public function create()
    {
        return view('admin.hopitaux.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'nom' => 'required|string|max:255',
            'adresse' => 'required|string|max:255',
            'telephone' => 'required|string|max:20',
            'email' => 'required|email|max:255',
        ]);

        Hopital::create([
            'nom' => $request->nom,
            'adresse' => $request->adresse,
            'telephone' => $request->telephone,
            'email' => $request->email,
        ]);

        return redirect()->route('admin.hopitaux.index')->with('success', 'Hôpital ajouté avec succès.');
    }

    public function edit($id)
    {
        $hopital = Hopital::findOrFail($id);
        return view('admin.hopitaux.edit', compact('hopital'));
    }

    public function update(Request $request, $id)
    {
        $request->validate([
            'nom' => 'required|string|max:255',
            'adresse' => 'required|string|max:255',
            'telephone' => 'required|string|max:20',
            'email' => 'required|email|max:255',
        ]);

        $hopital = Hopital::findOrFail($id);
        $hopital->update([
            'nom' => $request->nom,
            'adresse' => $request->adresse,
            'telephone' => $request->telephone,
            'email' => $request->email,
        ]);

        return redirect()->route('admin.hopitaux.index')->with('success', 'Hôpital modifié avec succès.');
    }
}
