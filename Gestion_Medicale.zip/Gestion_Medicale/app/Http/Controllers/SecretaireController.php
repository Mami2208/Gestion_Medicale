<?php

namespace App\Http\Controllers;

use App\Models\Patient;
use App\Models\Dossiers_Medicaux;  // Nom du modèle pour le dossier médical
use Illuminate\Http\Request;

class SecretaireController extends Controller
{
    public function dashboard()
    {
        $totalPatients = Patient::count();
        $totalDossiers = Dossiers_Medicaux::count();

        return view('secretaire.dashboard', [
            'totalPatients' => $totalPatients,
            'totalDossiers' => $totalDossiers,  // Affichage du nombre de dossiers médicaux
        ]);
    }

    public function createMedicalRecord()
    {
        $patients = Patient::all();
        return view('secretaire.medical_records.create', compact('patients'));
    }

    public function storeMedicalRecord(Request $request)
    {
        // Valider les données du formulaire
        $request->validate([
            'patient_id' => 'required|exists:patients,id',  // Vérifier que l'ID du patient existe
            'diagnostic' => 'required|string',  // Le diagnostic est obligatoire
            'prescription' => 'required|string',  // La prescription est obligatoire
        ]);

        // Créer un nouveau dossier médical
        Dossiers_Medicaux::create([
            'patient_id' => $request->patient_id,
            'diagnostic' => $request->diagnostic,
            'prescription' => $request->prescription,
        ]);

        // Rediriger vers le dashboard avec un message de succès
        return redirect()->route('secretaire.dashboard')->with('success', 'Dossier médical créé avec succès.');
    }
}
