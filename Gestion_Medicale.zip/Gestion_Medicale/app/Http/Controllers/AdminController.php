<?php

namespace App\Http\Controllers;

use App\Models\Utilisateur;
use App\Models\Hopital;
use App\Models\LogAccess;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use App\Mail\SecretaireCreated;

class AdminController extends Controller
{
    public function dashboard()
    {
        $medecins = Utilisateur::where('role', 'MEDECIN')->get();
        $secretaires = Utilisateur::where('role', 'SECRETAIRE')->get();
        $infirmiers = Utilisateur::where('role', 'INFIRMIER')->get();
        $totalHopitaux = Hopital::count();
        $totalLogs = LogAccess::count();

        // Active users: users created in last 30 days
        $activeUsersCount = Utilisateur::where('created_at', '>=', now()->subDays(30))->count();

        // Recent failed access attempts (last 5)
        $recentFailedAccesses = LogAccess::where('TypeAction', 'failed_login')
            ->orderBy('DateAction', 'desc')
            ->take(5)
            ->get();

        // Recent security alerts (last 5) - assuming TypeAction contains 'security_alert'
        $recentSecurityAlerts = LogAccess::where('TypeAction', 'like', '%security_alert%')
            ->orderBy('DateAction', 'desc')
            ->take(5)
            ->get();

        // Recent system activities (last 5) - assuming TypeAction contains 'system_activity'
        $recentSystemActivities = LogAccess::where('TypeAction', 'like', '%system_activity%')
            ->orderBy('DateAction', 'desc')
            ->take(5)
            ->get();

        return view('admin.dashboard', [
            'totalMedecins' => $medecins->count(),
            'totalSecretaires' => $secretaires->count(),
            'totalInfirmiers' => $infirmiers->count(),
            'totalHopitaux' => $totalHopitaux,
            'totalLogs' => $totalLogs,
            'activeUsersCount' => $activeUsersCount,
            'recentFailedAccesses' => $recentFailedAccesses,
            'recentSecurityAlerts' => $recentSecurityAlerts,
            'recentSystemActivities' => $recentSystemActivities,
        ]);
    }

    public function indexSecretaires()
    {
        $secretaires = Utilisateur::where('role', 'SECRETAIRE')->get();
        return view('admin.secretaires.index', compact('secretaires'));
    }

    public function createSecretaire()
    {
        $hopitaux = Hopital::all();
        return view('admin.secretaires.create', compact('hopitaux'));
    }

    public function storeSecretaire(Request $request)
    {
        $request->validate([
            'nom' => 'required|string|max:255',
            'prenom' => 'required|string|max:255',
            'email' => 'required|email|unique:utilisateurs,email',
            'mot_de_passe' => 'required|string|min:8|confirmed',
        ]);

        $password = $request->mot_de_passe;

        $secretaire = Utilisateur::create([
            'nom' => $request->nom,
            'prenom' => $request->prenom,
            'email' => $request->email,
            'mot_de_passe' => bcrypt($password),
            'role' => 'SECRETAIRE',
            'hopital_id' => $request->hopital_id,
            'telephone' => $request->telephone,
        ]);

        Mail::to($secretaire->email)->send(new SecretaireCreated($secretaire, $password));

        return redirect()->route('admin.secretaires.index')->with('success', 'Secrétaire créé avec succès.');
    }

    // New methods for infirmiers management

    public function indexInfirmiers()
    {
        $infirmiers = Utilisateur::where('role', 'INFIRMIER')->paginate(10);
        return view('admin.infirmiers.index', compact('infirmiers'));
    }

    public function createInfirmier()
    {
        return view('admin.infirmiers.create');
    }

    public function storeInfirmier(Request $request)
    {
        $request->validate([
            'nom' => 'required|string|max:255',
            'prenom' => 'required|string|max:255',
            'email' => 'required|email|unique:utilisateurs,email',
            'services' => 'nullable|string|max:255',
            'telephone' => 'nullable|string|max:20',
            'matricule' => 'nullable|string|max:255',
        ]);

        $infirmier = Utilisateur::create([
            'nom' => $request->nom,
            'prenom' => $request->prenom,
            'email' => $request->email,
            'mot_de_passe' => bcrypt(Str::random(8)),
            'role' => 'INFIRMIER',
            'telephone' => $request->telephone,
        ]);

        // Create infirmier record
        \App\Models\Infirmier::create([
            'id' => $infirmier->id,
            'matricule' => $request->matricule ?? '',
            'services' => $request->services,
        ]);

        // Optionally send email with password here

        return redirect()->route('admin.infirmiers.index')->with('success', 'Infirmier créé avec succès.');
    }
}
