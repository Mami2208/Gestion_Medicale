<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;

use Livewire\Livewire;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Livewire::component('medecin.patient-list', \App\Http\Livewire\Medecin\PatientList::class);
        Livewire::component('medecin.dossier-details', \App\Http\Livewire\Medecin\DossierDetails::class);
    }
}
