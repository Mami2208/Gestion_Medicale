<?php

namespace App\Livewire\Patient;

use Livewire\Component;

class Dossier extends Component
{
    public function render()
    {
        return view('livewire.patient.dossier');
    }
}
