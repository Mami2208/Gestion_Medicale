<?php

namespace App\Livewire\Patient;

use Livewire\Component;

class DicomViewer extends Component
{
    public function render()
    {
        return view('livewire.patient.dicom-viewer');
    }
}
