<?php

namespace App\Livewire\Patient;

use Livewire\Component;

class RDVs extends Component
{
    public function render()
    {
        return view('livewire.patient.r-d-vs');
    }
}
