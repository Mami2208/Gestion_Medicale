<?php

namespace App\Livewire\Admin;

use Livewire\Component;

class OrthancConfig extends Component
{
    public function render()
    {
        return view('livewire.admin.orthanc-config');
    }
}
