<?php

namespace App\Livewire\Secretaire;

use Livewire\Component;

class CreatePatient extends Component
{
    public function render()
    {
        return view('livewire.secretaire.create-patient');
    }
}
