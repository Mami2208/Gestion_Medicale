<?php

namespace App\Livewire\Secretaire;

use Livewire\Component;

class CreateDossier extends Component
{
    public function render()
    {
        return view('livewire.secretaire.create-dossier');
    }
}
