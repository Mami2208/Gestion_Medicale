<?php

namespace App\Livewire\Chercheur;

use Livewire\Component;

class CasAnonymes extends Component
{
    public function render()
    {
        return view('livewire.chercheur.cas-anonymes');
    }
}
