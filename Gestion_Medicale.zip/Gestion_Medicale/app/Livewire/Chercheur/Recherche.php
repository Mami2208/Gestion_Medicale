<?php

namespace App\Livewire\Chercheur;

use Livewire\Component;

class Recherche extends Component
{
    public function render()
    {
        return view('livewire.chercheur.recherche');
    }
}
