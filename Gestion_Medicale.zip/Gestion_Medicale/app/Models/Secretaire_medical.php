<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Secretaire_medical extends Model
{
    public function patient()
    {
        return $this->belongsTo(Patient::class);
    }
}
