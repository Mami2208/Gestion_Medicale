<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Patient extends Model
{
    public function dossiersMedicaux()
    {
        return $this->hasMany(Dossiers_Medicaux::class);
    }

    /**
     * Get the infirmier assigned to the patient.
     */
    public function infirmier(): BelongsTo
    {
        return $this->belongsTo(Infirmier::class);
    }
}
