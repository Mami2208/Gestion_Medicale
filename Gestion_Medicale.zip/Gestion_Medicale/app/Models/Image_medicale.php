<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Image_medicale extends Model
{
    //
}
