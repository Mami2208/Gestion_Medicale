<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class historique_medical extends Model
{
    //
}
