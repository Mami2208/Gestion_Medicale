<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Infirmier extends Model
{
    protected $fillable = [
        'id',
        'matricule',
        'services',
    ];

    /**
     * Get the patients assigned to the infirmier.
     */
    public function patients(): HasMany
    {
        return $this->hasMany(Patient::class);
    }
}
