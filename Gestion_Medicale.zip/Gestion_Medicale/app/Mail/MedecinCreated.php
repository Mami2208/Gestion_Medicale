<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use App\Models\Utilisateur;

class MedecinCreated extends Mailable
{
    use Queueable, SerializesModels;

    public $medecin;
    public $password;

    /**
     * Create a new message instance.
     *
     * @param Utilisateur $medecin
     * @param string $password
     */
    public function __construct(Utilisateur $medecin, $password)
    {
        $this->medecin = $medecin;
        $this->password = $password;
    }

    /**
     * Build the message.
     *
     * @return $this
     */
    public function build()
    {
        return $this->subject('Votre compte médecin a été créé')
                    ->view('emails.medecin_created')
                    ->with([
                        'medecin' => $this->medecin,
                        'password' => $this->password,
                    ]);
    }
}
