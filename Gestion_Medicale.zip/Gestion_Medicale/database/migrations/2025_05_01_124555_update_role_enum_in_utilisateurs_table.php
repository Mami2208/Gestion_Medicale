<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Facades\DB; // ← ajout important

return new class extends Migration {
    public function up(): void
    {
        DB::statement("ALTER TABLE utilisateurs MODIFY role ENUM('ADMIN', 'MEDECIN', 'INFIRMIER', 'SECRETAIRE') DEFAULT 'ADMIN'");
    }

    public function down(): void
    {
        DB::statement("ALTER TABLE utilisateurs MODIFY role ENUM('ADMIN', 'MEDECIN', 'INFIRMIER', 'SECRETAIRE MEDICAL') DEFAULT 'ADMIN'");
    }
};
