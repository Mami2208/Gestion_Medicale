<nav class="p-3 text-black ml-64" style="background-color: rgba(128, 128, 128, 0.05);">
    <div class="container mx-auto flex justify-between items-center">
        <div class="flex items-center space-x-4">
            <?php if(auth()->guard()->check()): ?>
                <?php if(Auth::user()->role === 'admin'): ?>
                    <span class="font-bold">Bienvenue, <?php echo e(Auth::user()->prenom); ?> <?php echo e(Auth::user()->nom); ?>!</span>
                <?php else: ?>
                    <span class="font-bold">Bienvenue, <?php echo e(Auth::user()->prenom ?? 'Utilisateur'); ?>!</span>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <div class="flex items-center space-x-4">
            <?php if(auth()->guard()->check()): ?>
                <a href="<?php echo e(route('medecin.dashboard')); ?>#notifications" class="text-gray-600 hover:text-gray-800" title="Notifications">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6 6 0 10-12 0v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                    </svg>
                </a>
                <div class="w-8 h-8 rounded-full bg-white text-teal-600 flex items-center justify-center mr-3 font-bold">
                    <span class="font-bold"><?php echo e(Auth::user()->initials ?? 'U'); ?></span>
                </div>
            <?php else: ?>
                <a href="<?php echo e(route('login')); ?>">Connexion</a>
            <?php endif; ?>
        </div>
    </div>
</nav>
<?php /**PATH C:\Users\Dabo\Desktop\Gestion_Medicale\resources\views/components/navbar.blade.php ENDPATH**/ ?>