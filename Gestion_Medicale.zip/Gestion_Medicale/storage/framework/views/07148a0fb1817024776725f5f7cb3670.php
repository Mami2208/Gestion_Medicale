<?php $__env->startSection('content'); ?>
<div>
    <?php echo $__env->make('components.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="ml-64 container mx-auto p-6 max-w-3xl">

        <div class="bg-white shadow rounded p-6 mt-4">
            <form action="<?php echo e(route('admin.medecins.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>

                <div class="mb-4">
                    <label for="nom" class="block font-semibold">Nom</label>
                    <input type="text" name="nom" id="nom" class="w-full border rounded p-2" value="<?php echo e(old('nom')); ?>">
                </div>

                <div class="mb-4">
                    <label for="prenom" class="block font-semibold">Prénom</label>
                    <input type="text" name="prenom" id="prenom" class="w-full border rounded p-2" value="<?php echo e(old('prenom')); ?>">
                </div>

                <div class="mb-4">
                    <label for="email" class="block font-semibold">Email</label>
                    <input type="email" name="email" id="email" class="w-full border rounded p-2" value="<?php echo e(old('email')); ?>">
                </div>

                <div class="mb-4">
                    <label for="specialite" class="block font-semibold">Spécialité</label>
                    <select name="specialite" id="specialite" class="w-full border rounded p-2">
                        <option value="">Sélectionnez une spécialité</option>
                        <?php $__currentLoopData = $specialites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($value); ?>" <?php echo e(old('specialite') == $value ? 'selected' : ''); ?>>
                                <?php echo e($value); ?>

                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div class="mb-4">
                    <label for="telephone" class="block font-semibold">Téléphone</label>
                    <input type="text" name="telephone" id="telephone" class="w-full border rounded p-2" value="<?php echo e(old('telephone')); ?>">
                </div>

                <div class="mb-4">
                    <label for="mot_de_passe" class="block font-semibold">Mot de passe</label>
                    <input type="password" name="mot_de_passe" id="mot_de_passe" class="w-full border rounded p-2">
                </div>

                <div class="mb-4">
                    <label for="mot_de_passe_confirmation" class="block font-semibold">Confirmation du mot de passe</label>
                    <input type="password" name="mot_de_passe_confirmation" id="mot_de_passe_confirmation" class="w-full border rounded p-2">
                </div>

                <div class="mt-6">
                    <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
                        Ajouter
                    </button>
                    <button type="reset" class="bg-gray-400 text-black px-4 py-2 rounded ml-2">Annuler</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Dabo\Desktop\Gestion_Medicale\resources\views/admin/medecins/create.blade.php ENDPATH**/ ?>