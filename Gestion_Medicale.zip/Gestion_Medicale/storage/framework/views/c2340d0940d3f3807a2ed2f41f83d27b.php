<?php $__env->startSection('content'); ?>
<div>
    <?php echo $__env->make('components.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="ml-64 container mx-auto px-4">
        <a href="<?php echo e(route('admin.medecins.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 mb-6 inline-block">
            Ajouter Médecin
        </a>

        <div class="mt-10">
            <h2 class="text-2xl font-bold mb-4">Liste des Médecins</h2>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white border border-gray-200 rounded-lg">
                    <thead>
                        <tr class="bg-gray-100 border-b border-gray-200">
                            <th class="text-left py-2 px-4 border-r border-gray-200">Nom</th>
                            <th class="text-left py-2 px-4 border-r border-gray-200">Prénom</th>
                            <th class="text-left py-2 px-4 border-r border-gray-200">Email</th>
                            <th class="text-left py-2 px-4 border-r border-gray-200">Spécialité</th>
                            <th class="text-left py-2 px-4">Téléphone</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $medecins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $medecin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="border-b border-gray-200 hover:bg-gray-50">
                                <td class="py-2 px-4 border-r border-gray-200"><?php echo e($medecin->nom); ?></td>
                                <td class="py-2 px-4 border-r border-gray-200"><?php echo e($medecin->prenom); ?></td>
                                <td class="py-2 px-4 border-r border-gray-200"><?php echo e($medecin->email); ?></td>
                                <td class="py-2 px-4 border-r border-gray-200">
                                    <?php
                                        $specialites = config('specialites.medicales');
                                        $specialiteKey = array_search($medecin->specialite, $specialites);
                                        $specialiteDisplay = $specialiteKey ? $specialites[$specialiteKey] : $medecin->specialite;
                                    ?>
                                    <?php echo e($specialiteDisplay); ?>

                                </td>
                                <td class="py-2 px-4"><?php echo e($medecin->telephone); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center py-4">Aucun médecin trouvé.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-4">
                <?php echo e($medecins->links()); ?>

            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Dabo\Desktop\Gestion_Medicale\resources\views/admin/medecins/index.blade.php ENDPATH**/ ?>