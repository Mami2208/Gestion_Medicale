<?php $__env->startSection('content'); ?>
<div>
    <?php echo $__env->make('components.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="ml-64 p-6">
        <h1 class="text-3xl font-bold mb-6">Tableau de bord Admin</h1>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            <!-- Gérer les médecins -->
            <a href="<?php echo e(route('admin.medecins.index')); ?>" class="bg-white rounded-lg shadow p-6 flex flex-col items-center justify-center hover:bg-teal-100 transition duration-200 cursor-pointer">
                <h2 class="text-xl font-semibold mb-2">Gérer les médecins</h2>
                <p class="text-3xl font-bold text-teal-600"><?php echo e($totalMedecins); ?></p>
            </a>

            <!-- Gérer les secrétaires -->
            <a href="<?php echo e(route('admin.secretaires.index')); ?>" class="bg-white rounded-lg shadow p-6 flex flex-col items-center justify-center hover:bg-teal-100 transition duration-200 cursor-pointer">
                <h2 class="text-xl font-semibold mb-2">Gérer les secrétaires</h2>
                <p class="text-3xl font-bold text-teal-600"><?php echo e($totalSecretaires); ?></p>
            </a>

            <!-- Gérer les hôpitaux -->
            <a href="<?php echo e(route('admin.hopitaux.index')); ?>" class="bg-white rounded-lg shadow p-6 flex flex-col items-center justify-center hover:bg-teal-100 transition duration-200 cursor-pointer">
                <h2 class="text-xl font-semibold mb-2">Gérer les hôpitaux</h2>
                <p class="text-3xl font-bold text-teal-600"><?php echo e($totalHopitaux); ?></p>
            </a>

            <!-- Voir les logs -->
            <a href="#" class="bg-white rounded-lg shadow p-6 flex flex-col items-center justify-center hover:bg-teal-100 transition duration-200 cursor-pointer">
                <h2 class="text-xl font-semibold mb-2">Voir les logs</h2>
                <p class="text-3xl font-bold text-teal-600"><?php echo e($totalLogs); ?></p>
            </a>
             <!-- Gérer les infirmiers -->
        <a href="<?php echo e(route('admin.infirmiers.index')); ?>" class="bg-white rounded-lg shadow p-6 flex flex-col items-center justify-center hover:bg-teal-100 transition duration-200 cursor-pointer">
            <h2 class="text-xl font-semibold mb-2">Gérer les infirmiers</h2>
            <p class="text-3xl font-bold text-teal-600"><?php echo e($totalInfirmiers); ?></p>
        </a>
        </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Dabo\Desktop\Gestion_Medicale\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>