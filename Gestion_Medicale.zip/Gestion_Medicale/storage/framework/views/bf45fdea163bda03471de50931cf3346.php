<?php $__env->startSection('content'); ?>
<div>
    <?php echo $__env->make('components.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="ml-64 container mx-auto px-4">
        <button id="toggleFormBtn" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 mb-6">Ajouter Infirmier</button>

        <div id="infirmierForm" class="hidden">
            <form action="<?php echo e(route('admin.infirmiers.store')); ?>" method="POST" class="bg-white p-6 rounded-lg shadow max-w-lg">
                <?php echo csrf_field(); ?>

                <div class="mb-4">
                    <label for="nom" class="block text-gray-700 font-semibold mb-2">Nom</label>
                    <input type="text" name="nom" id="nom" value="<?php echo e(old('nom')); ?>" required class="w-full border border-gray-300 rounded px-3 py-2">
                    <?php $__errorArgs = ['nom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label for="prenom" class="block text-gray-700 font-semibold mb-2">Prénom</label>
                    <input type="text" name="prenom" id="prenom" value="<?php echo e(old('prenom')); ?>" required class="w-full border border-gray-300 rounded px-3 py-2">
                    <?php $__errorArgs = ['prenom'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label for="email" class="block text-gray-700 font-semibold mb-2">Email</label>
                    <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" required class="w-full border border-gray-300 rounded px-3 py-2">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label for="services" class="block text-gray-700 font-semibold mb-2">Services</label>
                    <input type="text" name="services" id="services" value="<?php echo e(old('services')); ?>" class="w-full border border-gray-300 rounded px-3 py-2">
                    <?php $__errorArgs = ['services'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label for="matricule" class="block text-gray-700 font-semibold mb-2">Matricule</label>
                    <input type="text" name="matricule" id="matricule" value="<?php echo e(old('matricule')); ?>" class="w-full border border-gray-300 rounded px-3 py-2">
                    <?php $__errorArgs = ['matricule'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label for="telephone" class="block text-gray-700 font-semibold mb-2">Téléphone</label>
                    <input type="text" name="telephone" id="telephone" value="<?php echo e(old('telephone')); ?>" class="w-full border border-gray-300 rounded px-3 py-2">
                    <?php $__errorArgs = ['telephone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label for="mot_de_passe" class="block text-gray-700 font-semibold mb-2">Mot de passe</label>
                    <input type="password" name="mot_de_passe" id="mot_de_passe" class="w-full border border-gray-300 rounded px-3 py-2">
                    <?php $__errorArgs = ['mot_de_passe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label for="mot_de_passe_confirmation" class="block text-gray-700 font-semibold mb-2">Confirmation du mot de passe</label>
                    <input type="password" name="mot_de_passe_confirmation" id="mot_de_passe_confirmation" class="w-full border border-gray-300 rounded px-3 py-2">
                    <?php $__errorArgs = ['mot_de_passe_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-sm mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Ajouter</button>
            </form>
        </div>

        <div class="mt-10">
            <h2 class="text-2xl font-bold mb-4">Liste des Infirmiers</h2>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white border border-gray-200 rounded-lg">
                    <thead>
                        <tr class="bg-gray-100 border-b border-gray-200">
                            <th class="text-left py-2 px-4 border-r border-gray-200">Nom</th>
                            <th class="text-left py-2 px-4 border-r border-gray-200">Prénom</th>
                            <th class="text-left py-2 px-4 border-r border-gray-200">Email</th>
                            <th class="text-left py-2 px-4 border-r border-gray-200">Services</th>
                            <th class="text-left py-2 px-4 border-r border-gray-200">Matricule</th>
                            <th class="text-left py-2 px-4">Téléphone</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $infirmiers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $infirmier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="border-b border-gray-200 hover:bg-gray-50">
                                <td class="py-2 px-4 border-r border-gray-200"><?php echo e($infirmier->nom); ?></td>
                                <td class="py-2 px-4 border-r border-gray-200"><?php echo e($infirmier->prenom); ?></td>
                                <td class="py-2 px-4 border-r border-gray-200"><?php echo e($infirmier->email); ?></td>
                                <td class="py-2 px-4 border-r border-gray-200"><?php echo e($infirmier->infirmier->services ?? ''); ?></td>
                                <td class="py-2 px-4 border-r border-gray-200"><?php echo e($infirmier->infirmier->matricule ?? ''); ?></td>
                                <td class="py-2 px-4"><?php echo e($infirmier->telephone ?? ''); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="6" class="text-center py-4">Aucun infirmier trouvé.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-4">
                <?php echo e($infirmiers->links()); ?>

            </div>
        </div>
    </div>
</div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        var toggleBtn = document.getElementById('toggleFormBtn');
        var formDiv = document.getElementById('infirmierForm');
        toggleBtn.addEventListener('click', function () {
            if (formDiv.classList.contains('hidden')) {
                formDiv.classList.remove('hidden');
            } else {
                formDiv.classList.add('hidden');
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Dabo\Desktop\Gestion_Medicale\resources\views/admin/infirmiers/index.blade.php ENDPATH**/ ?>