<?php $__env->startSection('content'); ?>
<div>
    <?php echo $__env->make('components.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="ml-64 container mx-auto p-6 max-w-3xl">
        <a href="<?php echo e(route('admin.secretaires.index')); ?>" class="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">
            Retour à la liste
        </a>
        <div class="bg-white shadow rounded p-6 mt-4 ">
        <form action="<?php echo e(route('admin.secretaires.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>

            <div class="mb-4">
                <label for="nom" class="block text-gray-700 font-bold mb-2">Nom</label>
                <input type="text" name="nom" id="nom" value="<?php echo e(old('nom')); ?>" required class="w-full border border-gray-300 rounded px-3 py-2">
            </div>

            <div class="mb-4">
                <label for="prenom" class="block text-gray-700 font-bold mb-2">Prénom</label>
                <input type="text" name="prenom" id="prenom" value="<?php echo e(old('prenom')); ?>" required class="w-full border border-gray-300 rounded px-3 py-2">
            </div>

            <div class="mb-4">
                <label for="email" class="block text-gray-700 font-bold mb-2">Email</label>
                <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" required class="w-full border border-gray-300 rounded px-3 py-2">
            </div>

            <div class="mb-4">
                <label for="telephone" class="block text-gray-700 font-bold mb-2">Téléphone</label>
                <input type="number" name="telephone" id="telephone" value="<?php echo e(old('telephone')); ?>" required class="w-full border border-gray-300 rounded px-3 py-2">
            </div>

            <div class="mb-4">
                <label for="hopital_id" class="block text-gray-700 font-bold mb-2">Hôpital</label>
                <select name="hopital_id" id="hopital_id" required class="w-full border border-gray-300 rounded px-3 py-2">
                    <?php $__currentLoopData = $hopitaux; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hopital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($hopital->id); ?>" <?php echo e(old('hopital_id') == $hopital->id ? 'selected' : ''); ?>>
                            <?php echo e($hopital->nom); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="mb-4">
                <label for="mot_de_passe" class="block text-gray-700 font-bold mb-2">Mot de passe</label>
                <input type="password" name="mot_de_passe" id="mot_de_passe" required class="w-full border border-gray-300 rounded px-3 py-2">
            </div>

            <div class="mb-4">
                <label for="mot_de_passe_confirmation" class="block text-gray-700 font-bold mb-2">Confirmation du mot de passe</label>
                <input type="password" name="mot_de_passe_confirmation" id="mot_de_passe_confirmation" required class="w-full border border-gray-300 rounded px-3 py-2">
            </div>

            <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Créer le secrétaire</button>
        </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Dabo\Desktop\Gestion_Medicale\resources\views/admin/secretaires/create.blade.php ENDPATH**/ ?>