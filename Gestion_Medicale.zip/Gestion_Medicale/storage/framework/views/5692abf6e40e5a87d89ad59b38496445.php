<div>
    <!--[if BLOCK]><![endif]--><?php if($dossier): ?>
        <h3 class="text-lg font-semibold mb-2">Dossier médical de <?php echo e($dossier->patient->nom ?? ''); ?> <?php echo e($dossier->patient->prenom ?? ''); ?></h3>
        <p><?php echo e($dossier->description ?? 'Aucune description disponible'); ?></p>

        <h4 class="mt-4 font-semibold">Images DICOM associées</h4>
        <!--[if BLOCK]><![endif]--><?php if($dicomImages->isEmpty()): ?>
            <p>Aucune image DICOM disponible pour ce patient.</p>
        <?php else: ?>
            <ul class="list-disc list-inside">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $dicomImages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(url('/view/' . $image->dicom->orthanc_id)); ?>" target="_blank" class="text-blue-600 hover:underline">
                            Étude du <?php echo e($image->dicom->study_date ?? 'date inconnue'); ?>

                        </a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </ul>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    <?php else: ?>
        <p>Sélectionnez un patient pour voir les détails du dossier médical.</p>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
</div>
<?php /**PATH C:\Users\Dabo\Desktop\Gestion_Medicale\resources\views/livewire/medecin/dossier-details.blade.php ENDPATH**/ ?>