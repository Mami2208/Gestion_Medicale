<div>
    <label for="specialite" class="block font-medium text-sm text-gray-700">Filtrer par spécialité</label>
    <select wire:model="specialite" id="specialite" class="form-select mt-1 block w-full">
        <option value="">-- Sélectionnez une spécialité --</option>
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $specialites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($specialite); ?>"><?php echo e($specialite); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </select>

    <div class="mt-4">
        <!--[if BLOCK]><![endif]--><?php if($patients->isEmpty()): ?>
            <p>Aucun patient trouvé pour cette spécialité.</p>
        <?php else: ?>
            <ul class="divide-y divide-gray-200">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="py-2 cursor-pointer hover:bg-gray-100" wire:click="$emit('patientSelected', <?php echo e($patient->id); ?>)">
                        <?php echo e($patient->nom); ?> <?php echo e($patient->prenom); ?>

                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </ul>
        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH C:\Users\Dabo\Desktop\Gestion_Medicale\resources\views/livewire/medecin/patient-list.blade.php ENDPATH**/ ?>