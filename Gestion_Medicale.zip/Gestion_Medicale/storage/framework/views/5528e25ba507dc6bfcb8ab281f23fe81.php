<?php $__env->startSection('content'); ?>
<div>
    <?php echo $__env->make('components.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="ml-64 container mx-auto p-6 max-w-lg">
        <a href="<?php echo e(route('admin.secretaires.create')); ?>" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700 mb-6 inline-block">
            Ajouter Secrétaire
        </a>

        <div class="mt-10">
            <h2 class="text-2xl font-bold mb-4">Liste des Secrétaires</h2>
            <div class="overflow-x-auto">
                <table class="min-w-full bg-white border border-gray-200 rounded-lg">
                    <thead>
                        <tr class="bg-gray-100 border-b border-gray-200">
                            <th class="text-left py-2 px-4 border-r border-gray-200">Nom</th>
                            <th class="text-left py-2 px-4 border-r border-gray-200">Prénom</th>
                            <th class="text-left py-2 px-4 border-r border-gray-200">Email</th>
                            <th class="text-left py-2 px-4">Téléphone</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $secretaires; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $secretaire): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr class="border-b border-gray-200 hover:bg-gray-50">
                                <td class="py-2 px-4 border-r border-gray-200"><?php echo e($secretaire->nom); ?></td>
                                <td class="py-2 px-4 border-r border-gray-200"><?php echo e($secretaire->prenom); ?></td>
                                <td class="py-2 px-4 border-r border-gray-200"><?php echo e($secretaire->email); ?></td>
                                <td class="py-2 px-4"><?php echo e($secretaire->telephone); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="4" class="text-center py-4">Aucun secrétaire trouvé.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Dabo\Desktop\Gestion_Medicale\resources\views/admin/secretaires/index.blade.php ENDPATH**/ ?>