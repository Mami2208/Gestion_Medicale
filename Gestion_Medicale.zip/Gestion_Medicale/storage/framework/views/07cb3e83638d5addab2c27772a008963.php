<?php $__env->startSection('content'); ?>
<div class="ml-64 p-6">

    <?php echo $__env->make('components.admin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <a href="<?php echo e(route('admin.hopitaux.create')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded mb-4 inline-block">Ajouter un hôpital</a>


    <h1 class="text-2xl font-bold mb-4">Liste des hôpitaux</h1>

    <?php if(session('success')): ?>
        <div class="bg-green-100 text-green-700 p-3 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <table class="w-full bg-white shadow rounded">
        <thead>
            <tr class="bg-gray-100">
                <th class="p-2 text-left">Nom</th>
                <th class="p-2 text-left">Adresse</th>
                <th class="p-2 text-left">Téléphone</th>
                <th class="p-2 text-left">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $hopitaux; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hopital): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="border-t">
                    <td class="p-2"><?php echo e($hopital->nom); ?></td>
                    <td class="p-2"><?php echo e($hopital->adresse); ?></td>
                    <td class="p-2"><?php echo e($hopital->telephone); ?></td>
                    <td class="p-2">
                        <a href="<?php echo e(route('admin.hopitaux.edit', $hopital->id)); ?>" class="text-blue-500 mr-2">Modifier</a>


                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Dabo\Desktop\Gestion_Medicale\resources\views/admin/hopitaux/index.blade.php ENDPATH**/ ?>