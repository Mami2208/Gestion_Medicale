<?php $__env->startSection('content'); ?>
<div class="min-h-screen bg-gray-100">
    <?php echo $__env->make('components.medecin-sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <main class="flex-1 p-6 ml-64">
        <h1 class="text-2xl font-semibold mb-6">Tableau de bord Médecin</h1>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6" id="appointments">
            <div class="bg-white shadow rounded-lg p-6">
                <h2 class="text-xl font-semibold mb-4">Rendez-vous à venir</h2>
                <?php if($appointments->isEmpty()): ?>
                    <p class="text-gray-600">Vous n'avez aucun rendez-vous à venir.</p>
                <?php else: ?>
                    <table class="min-w-full divide-y divide-gray-200">
                        <thead>
                            <tr>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Patient</th>
                                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Statut</th>
                            </tr>
                        </thead>
                        <tbody class="bg-white divide-y divide-gray-200">
                            <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e(\Carbon\Carbon::parse($appointment->date_rendez_vous)->format('d/m/Y H:i')); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e($appointment->patient->nom ?? 'N/A'); ?> <?php echo e($appointment->patient->prenom ?? ''); ?></td>
                                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e(ucfirst($appointment->statut ?? 'En attente')); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>

            <div class="bg-white shadow rounded-lg p-6">
                <h2 class="text-xl font-semibold mb-4">Traitements récents</h2>
                <?php if($treatments->isEmpty()): ?>
                    <p class="text-gray-600">Aucun traitement récent.</p>
                <?php else: ?>
                    <ul class="list-disc list-inside">
                        <?php $__currentLoopData = $treatments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $treatment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($treatment->created_at->format('d/m/Y')); ?> - <?php echo e($treatment->description ?? 'Description non disponible'); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6" id="prescriptions">
            <div class="bg-white shadow rounded-lg p-6">
                <h2 class="text-xl font-semibold mb-4">Prescriptions récentes</h2>
                <?php if($prescriptions->isEmpty()): ?>
                    <p class="text-gray-600">Aucune prescription récente.</p>
                <?php else: ?>
                    <ul class="list-disc list-inside">
                        <?php $__currentLoopData = $prescriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prescription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($prescription->created_at->format('d/m/Y')); ?> - <?php echo e($prescription->description ?? 'Description non disponible'); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>

            <div class="bg-white shadow rounded-lg p-6" id="notifications">
                <h2 class="text-xl font-semibold mb-4">Notifications récentes</h2>
                <?php if($notifications->isEmpty()): ?>
                    <p class="text-gray-600">Aucune notification récente.</p>
                <?php else: ?>
                    <ul class="list-disc list-inside">
                        <?php $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($notification->created_at->format('d/m/Y H:i')); ?> - <?php echo e($notification->message ?? 'Message non disponible'); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </main>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Dabo\Desktop\Gestion_Medicale\resources\views/medecin/dashboard.blade.php ENDPATH**/ ?>