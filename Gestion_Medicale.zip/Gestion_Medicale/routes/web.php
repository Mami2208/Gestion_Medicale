<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Auth\LoginController;
use App\Http\Controllers\AdminController;
use App\Http\Controllers\MedecinController;
use App\Http\Controllers\HopitalController;
use App\Http\Middleware\CheckRole;
use App\Http\Controllers\SecretaireController;
use App\Http\Controllers\PatientController;

// Routes publiques
Route::get('/', function () {
    return view('welcome');
});

// Authentification
Route::controller(LoginController::class)->group(function () {
    Route::get('/login', 'show')->name('login')->middleware('guest');
    Route::post('/login', 'login');
    Route::post('/logout', 'logout')->name('logout')->middleware('auth');
});

Route::middleware(['auth'])->group(function () {
    // Tableau de bord principal


    // Dashboard Médecin
    Route::middleware([CheckRole::class . ':MEDECIN'])->prefix('medecin')->group(function () {
        Route::get('/dashboard', [MedecinController::class, 'dashboard'])->name('medecin.dashboard');
    });

// Dashboard Patient
Route::middleware([CheckRole::class . ':PATIENT'])->prefix('patient')->group(function () {
    Route::get('/dashboard', [PatientController::class, 'dashboard'])->name('patient.dashboard');
    Route::get('/profile', [PatientController::class, 'profile'])->name('patient.profile');
    Route::get('/appointments', [PatientController::class, 'appointments'])->name('patient.appointments');
    Route::get('/medical-records', [PatientController::class, 'medicalRecords'])->name('patient.medical_records');
});

// Dashboard Infirmier
Route::middleware([CheckRole::class . ':INFIRMIER'])->prefix('infirmier')->group(function () {
    Route::get('/dashboard', function () {
        return view('infirmier');
    })->name('infirmier.dashboard');
});

    // Administration (réservé aux ADMIN)
    Route::middleware([CheckRole::class . ':ADMIN'])->prefix('admin')->name('admin.')->group(function () {
        Route::get('/dashboard', [AdminController::class, 'dashboard'])->name('dashboard');

        // Gestion des médecins
        Route::controller(MedecinController::class)->prefix('medecins')->group(function () {
            Route::get('/', 'index')->name('medecins.index');
            Route::get('/create', 'create')->name('medecins.create');
            Route::post('/', 'store')->name('medecins.store');
        });

        // Gestion des secrétaires
        Route::prefix('secretaires')->group(function () {
            Route::get('/', [AdminController::class, 'indexSecretaires'])->name('secretaires.index');
            Route::get('/create', [AdminController::class, 'createSecretaire'])->name('secretaires.create');
            Route::post('/', [AdminController::class, 'storeSecretaire'])->name('secretaires.store');
        });

        // Gestion des infirmiers
        Route::prefix('infirmiers')->group(function () {
            Route::get('/', [AdminController::class, 'indexInfirmiers'])->name('infirmiers.index');
            Route::get('/create', [AdminController::class, 'createInfirmier'])->name('infirmiers.create');
            Route::post('/', [AdminController::class, 'storeInfirmier'])->name('infirmiers.store');
        });

        // Gestion des hôpitaux
        Route::prefix('hopitaux')->group(function () {
            Route::get('/', [HopitalController::class, 'index'])->name('hopitaux.index');
            Route::get('/create', [HopitalController::class, 'create'])->name('hopitaux.create');
            Route::post('/', [HopitalController::class, 'store'])->name('hopitaux.store');
            Route::get('/{hopital}/edit', [HopitalController::class, 'edit'])->name('hopitaux.edit');
            Route::put('/{hopital}', [HopitalController::class, 'update'])->name('hopitaux.update');
        });

    });

    // Dashboard Secrétaire
    Route::middleware([CheckRole::class . ':SECRETAIRE MEDICAL'])->prefix('secretaire')->group(function () {
        Route::get('/dashboard', [SecretaireController::class, 'dashboard'])->name('secretaire.dashboard');
        Route::get('/medical-records/create', [SecretaireController::class, 'createMedicalRecord'])->name('secretaire.medical_records.create');
        Route::post('/medical-records', [SecretaireController::class, 'storeMedicalRecord'])->name('secretaire.medical_records.store');
    });
});
