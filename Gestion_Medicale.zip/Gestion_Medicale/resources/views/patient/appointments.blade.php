@extends('layouts.app')

@section('content')
<div class="container mx-auto p-6">
    <h1 class="text-3xl font-bold mb-6">Rendez-vous du patient</h1>
    <p>Liste des rendez-vous du patient.</p>
    <!-- Add patient appointments content here -->
</div>
@endsection
