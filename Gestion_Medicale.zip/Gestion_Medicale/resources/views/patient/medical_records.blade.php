@extends('layouts.app')

@section('content')
<div class="container mx-auto p-6">
    <h1 class="text-3xl font-bold mb-6">Dossiers médicaux du patient</h1>
    <p>Liste des dossiers médicaux du patient.</p>
    <!-- Add patient medical records content here -->
</div>
@endsection
