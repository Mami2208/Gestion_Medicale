@extends('layouts.app')

@section('content')
<div class="container mx-auto p-6">
    <h1 class="text-3xl font-bold mb-6">Tableau de bord du patient</h1>
    <p>Bienvenue sur votre tableau de bord.</p>
    <!-- Add patient dashboard content here -->
</div>
@endsection
