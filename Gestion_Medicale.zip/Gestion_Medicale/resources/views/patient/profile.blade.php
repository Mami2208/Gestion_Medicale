@extends('layouts.app')

@section('content')
<div class="container mx-auto p-6">
    <h1 class="text-3xl font-bold mb-6">Profil du patient</h1>
    <p>Informations personnelles et paramètres du patient.</p>
    <!-- Add patient profile content here -->
</div>
@endsection
