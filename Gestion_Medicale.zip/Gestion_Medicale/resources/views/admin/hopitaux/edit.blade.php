@extends('layouts.app')

@section('content')
<div>
    @include('components.admin-sidebar')

    <div class="ml-64 container mx-auto px-4 max-w-3xl">

        <form action="{{ route('admin.hopitaux.update', $hopital->id) }}" method="POST" class="bg-white p-6 rounded-lg shadow max-w-lg">
            @csrf
            @method('PUT')

            <div class="mb-4">
                <label for="nom" class="block text-gray-700 font-semibold mb-2">Nom</label>
                <input type="text" name="nom" id="nom" value="{{ old('nom', $hopital->nom) }}" required class="w-full border border-gray-300 rounded px-3 py-2">
                @error('nom')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="mb-4">
                <label for="adresse" class="block text-gray-700 font-semibold mb-2">Adresse</label>
                <input type="text" name="adresse" id="adresse" value="{{ old('adresse', $hopital->adresse) }}" required class="w-full border border-gray-300 rounded px-3 py-2">
                @error('adresse')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="mb-4">
                <label for="telephone" class="block text-gray-700 font-semibold mb-2">Téléphone</label>
                <input type="text" name="telephone" id="telephone" value="{{ old('telephone', $hopital->telephone) }}" required class="w-full border border-gray-300 rounded px-3 py-2">
                @error('telephone')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <div class="mb-4">
                <label for="email" class="block text-gray-700 font-semibold mb-2">Email</label>
                <input type="email" name="email" id="email" value="{{ old('email', $hopital->email) }}" required class="w-full border border-gray-300 rounded px-3 py-2">
                @error('email')
                    <p class="text-red-500 text-sm mt-1">{{ $message }}</p>
                @enderror
            </div>

            <button type="submit" class="bg-blue-500 text-white px-4 py-2 rounded">Modifier</button>
            <a href="{{ route('admin.hopitaux.index') }}" class="bg-gray-400 text-black px-4 py-2 rounded ml-2 inline-block">Annuler</a>
        </form>

    </div>
</div>
@endsection
