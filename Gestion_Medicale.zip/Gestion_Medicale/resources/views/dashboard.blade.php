@extends('layouts.app')

@section('content')
    @livewire('dashboard')
@endsection
