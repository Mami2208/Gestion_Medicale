<div class="container mx-auto p-6 max-w-4xl">
    <h1 class="text-3xl font-bold mb-6">Configuration Orthanc</h1>

    @if(session()->has('success'))
        <div class="bg-green-100 text-green-700 p-3 rounded mb-4">
            {{ session('success') }}
        </div>
    @endif

    <form wire:submit.prevent="save" class="space-y-4">
        <div>
            <label for="orthancUrl" class="block font-semibold mb-1">URL Orthanc</label>
            <input type="text" id="orthancUrl" wire:model="orthancUrl" class="w-full border border-gray-300 rounded px-3 py-2" />
        </div>

        <div>
            <label for="orthancUsername" class="block font-semibold mb-1">Nom d'utilisateur</label>
            <input type="text" id="orthancUsername" wire:model="orthancUsername" class="w-full border border-gray-300 rounded px-3 py-2" />
        </div>

        <div>
            <label for="orthancPassword" class="block font-semibold mb-1">Mot de passe</label>
            <input type="password" id="orthancPassword" wire:model="orthancPassword" class="w-full border border-gray-300 rounded px-3 py-2" />
        </div>

        <button type="submit" class="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700">Sauvegarder</button>
    </form>
</div>
