<div>
    @if($tasks->isEmpty())
        <p>Aucune tâche de soin à effectuer.</p>
    @else
        <table class="min-w-full bg-white border border-gray-200">
            <thead>
                <tr>
                    <th class="py-2 px-4 border-b">Patient</th>
                    <th class="py-2 px-4 border-b">Traitement</th>
                    <th class="py-2 px-4 border-b">Statut</th>
                </tr>
            </thead>
            <tbody>
                @foreach($tasks as $task)
                    <tr>
                        <td class="py-2 px-4 border-b">{{ $task->patient->name ?? 'Nom non disponible' }}</td>
                        <td class="py-2 px-4 border-b">{{ $task->description ?? 'Description non disponible' }}</td>
                        <td class="py-2 px-4 border-b">{{ $task->status ?? 'Statut inconnu' }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @endif
</div>
