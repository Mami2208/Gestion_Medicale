<div>
    @if($patients->isEmpty())
        <p>Aucun patient assigné.</p>
    @else
        <table class="min-w-full bg-white border border-gray-200">
            <thead>
                <tr>
                    <th class="py-2 px-4 border-b">Nom du Patient</th>
                    <th class="py-2 px-4 border-b">Priorité</th>
                </tr>
            </thead>
            <tbody>
                @foreach($patients as $patient)
                    <tr>
                        <td class="py-2 px-4 border-b">{{ $patient->name ?? 'Nom non disponible' }}</td>
                        <td class="py-2 px-4 border-b">
                            @php
                                // Example priority logic: check if patient has urgent medical records or flags
                                $priority = 'Normal';
                                $priorityClass = 'bg-green-200 text-green-800';
                                // This is placeholder logic; adjust as needed
                                if ($patient->dossiersMedicaux->count() > 0) {
                                    $priority = 'Urgent';
                                    $priorityClass = 'bg-red-200 text-red-800';
                                }
                            @endphp
                            <span class="px-2 py-1 rounded {{ $priorityClass }}">{{ $priority }}</span>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @endif
</div>
