<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Compte Médecin Créé</title>
</head>
<body>
    <p>Bonjour {{ $medecin->prenom }} {{ $medecin->nom }},</p>

    <p>Votre compte médecin a été créé avec succès.</p>

    <p>Voici vos informations de connexion :</p>
    <ul>
        <li>Email : {{ $medecin->email }}</li>
        <li>Mot de passe : {{ $password }}</li>
    </ul>

    <p>Nous vous recommandons de changer votre mot de passe après votre première connexion.</p>

    <p>Cordialement,<br>L'équipe de gestion médicale</p>
</body>
</html>
