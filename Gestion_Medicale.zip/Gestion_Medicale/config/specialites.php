<?php

return [
    'medicales' => [
        'GENERALISTE' => 'Médecine générale',
        'CARDIOLOGUE' => 'Cardiologie',
        'DERMATOLOGUE' => 'Dermatologie',
        'PEDIATRE' => 'Pédiatrie',
        'RADIOLOGUE' => 'Radiologie',
        'AUTRES' => 'Autres'
    ]
];